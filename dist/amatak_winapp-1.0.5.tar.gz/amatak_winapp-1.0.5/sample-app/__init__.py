"""
Auto-generated package initialization.
Copyright (c) 2025 Amatak Holdings Pty Ltd.
"""

__version__ = "1.0.4"
from . import main

__all__ = ['main', '__version__']
