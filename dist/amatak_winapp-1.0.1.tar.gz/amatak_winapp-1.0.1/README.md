Copyright (c) 2025 Amatak Holdings Pty Ltd.

# Amatak WinApp

A comprehensive Python toolkit for creating professional Windows application installers.

## Installation

```bash
pip install amatak-winapp
# Create a new Windows application project
winapp create MyApp

# Navigate to project
cd MyApp

# Initialize with branding and documentation
winapp init

# Build the installer
winapp build
```

