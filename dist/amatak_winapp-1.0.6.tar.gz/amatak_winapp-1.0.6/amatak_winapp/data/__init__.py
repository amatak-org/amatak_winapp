"""
Auto-generated package initialization.
Copyright (c) 2026 Amatak Holdings Pty Ltd.
"""

__version__ = "1.0.6"
__all__ = ['__version__']
