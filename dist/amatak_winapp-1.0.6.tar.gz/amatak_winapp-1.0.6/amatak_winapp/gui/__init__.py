"""
Auto-generated package initialization.
Copyright (c) 2026 Amatak Holdings Pty Ltd.
"""

__version__ = "1.0.6"
from . import winapp_gui

__all__ = ['winapp_gui', '__version__']
