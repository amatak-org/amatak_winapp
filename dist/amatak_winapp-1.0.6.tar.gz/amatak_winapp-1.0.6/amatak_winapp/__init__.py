"""
Auto-generated package initialization.
Copyright (c) 2026 Amatak Holdings Pty Ltd.
"""

__version__ = "1.0.6"
from . import this_init
from . import winapp

__all__ = ['this_init', 'winapp', '__version__']
