"""
Auto-generated package initialization.
Copyright (c) 2025 Amatak Holdings Pty Ltd.
"""

__version__ = "1.0.3"
from . import winapp_gui

__all__ = ['winapp_gui', '__version__']
